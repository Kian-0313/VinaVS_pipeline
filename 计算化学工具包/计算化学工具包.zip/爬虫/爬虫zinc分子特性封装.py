# -*- coding: utf-8 -*-
"""
Created on Mon Dec  9 16:38:01 2024

@author: yqz
"""
import os
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from bs4 import BeautifulSoup
import time
import re
import pandas as pd



# 示例：提取 SMILES, LogP 和分子量
#输入zinc的id列表
def get_compound_data(zinc_ids,driver,savepath):
        '''设置Chrome浏览器选项 ,已经在主函数声明'''
        # options = webdriver.ChromeOptions()
        # options.add_argument('--headless')  # 可选，启动无头模式
        # options.add_argument(r"user-data-dir='F:/docking_dataset/'")
        # # 初始化ChromeDriver

        # # 使用 WebDriver Manager 自动安装并启动 ChromeDriver
        # driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))

        pattern1 = r'(\d{4}-\d{2}-\d{2})\s+([A-Za-z-]+)\s+(\d{4}-\d{2}-\d{2})\s+([\d\.]+)\s+([\d\.]+)'
        pattern2 = r"([A-Za-z0-9]+)\s*(\d+)\s*(\d+)\s*(\d+)\s*([\d.]+)\s*([\w]+)"
        
        #初始化信息记录表
        imformation=pd.DataFrame(columns=['ZINC_ID','Smiles','Added','Availability','Since','molecular_weight','logp',
                                          'Mol_Formula','rings_num','heavy_atoms','heatero_atoms','fraction_sp',
                                          'r_ph','r_Net_charge','r_Hbond_donors','r_Hbond_acceptors','r_tPSA','r_Rotatable_bonds','r_Apolar_desolvation','r_Polar_desolvation',                              
                                          'custom_ph','custom_Net_charge','custom_Hbond_donors','custom_Hbond_acceptors','custom_tPSA','custom_Rotatable_bonds','custom_Apolar_desolvation','custom_Polar_desolvation'
                                          ])
        
        # 如果文件存在，则读取文件
        if os.path.exists(savepath):     
            confirm = pd.read_csv(savepath)
            id_ = len(confirm)
            start=id_+1
        else:
            start=0
            
        
        zinc_ids=zinc_ids[start:]
        for zinc_id in zinc_ids : 
            
            print(zinc_id,start)           
            start+=1
            url = f"https://zinc15.docking.org/substances/{zinc_id}" # 替换为实际的 URL   
            info_list=[]
            three_d=[]
            all_info=[]
            driver.get(url)
        
            # 等待页面加载完成（根据需要调整等待时间）
            time.sleep(5)  # 等待 5 秒钟，确保 JavaScript 渲染完毕
        
            # 获取页面源代码
            page_source = driver.page_source
        
            # 使用 BeautifulSoup 解析页面
            soup = BeautifulSoup(page_source, 'html.parser')
            
            # 查找 Smiles 信息
            smiles_input = soup.find('input', id='substance-smiles-field')
                
            # 如果找到了该元素，返回其value属性
            if smiles_input and 'value' in smiles_input.attrs:
                smiles = smiles_input['value']
            else:
                return "SMILES字符串未找到"
            # 查找信息
           
            info1 = soup.find('th', text='logP').find_next('tr').text#确定具有唯一性的位置
            info2 = soup.find('th', text='Mol Formula').find_next('tr').text#确定具有唯一性的位置
            matches1 = re.search(pattern1, info1.strip())
            matches2 = re.search(pattern2, info2.strip())
            
            # date_1 = matches1.group(1)      #添加日期
            # status = matches1.group(2)      #上架状态
            # date_2 = matches1.group(3)      #修改日期  
            # molecular_weight = matches1.group(4)  #分子量
            # logp = matches1.group(5)        #logp
            
           
            # three_d.append(date_1)  # Added 
            # three_d.append(status)  # Availability 
            # three_d.append(molecular_weight)  # Since
            # three_d.append(matches1.group(4))  # molecular_weight 
            # three_d.append(matches1.group(5))  # logp 
            
            # three_d.append(matches2.group(1))  # Mol_Formula 
            # three_d.append(matches2.group(2))  # rings_num 
            # three_d.append(matches2.group(3))  # heavy_atoms
            # three_d.append(matches2.group(4))  # heatero_atoms
            # three_d.append(matches2.group(5))  # fraction_sp
            
            for c in range(1,6):
                add=matches1.group(c)
                three_d.append(matches1.group(c))
                
                
            for c in range(1,6):
                three_d.append(matches2.group(c))
            
            
            td_with_title = soup.find_all('td', title=True)
            
            for td in td_with_title:
                info_list.append(td.text.strip())
        
            # Reference=info_list[1:8]
            # High_ph= info_list[10:17]
            all_info.append(zinc_id)
            all_info.append(smiles)
            all_info= all_info+three_d+info_list[0:8]+info_list[9:17]
            if len(all_info) < 28:
                all_info.extend([None] * (28 - len(all_info)))

            
            
            imformation.loc[len(imformation)] = all_info
           
        
            # logp = soup.find_all('span', class_='logp-class')  # 根据实际class或ID修改
            # logp = logp.text.strip() if logp else 'Not Found'
        
            # 查找分子量信息
            # mwt_value = soup.find('th', text='Mwt').find_next('tr').text
            # molecular_weight = soup.find_all('span', class_='molecular-weight-class')  # 根据实际class或ID修改
            # molecular_weight = molecular_weight.text.strip() if molecular_weight else 'Not Found'
            imformation.to_csv(savepath)
            
            
        # driver.quit()
        
        return imformation
        

# df=pd.read_csv('F:/docking_dataset/27w_docking_results/Best_Score/Best_Score.csv')
# df=pd.read_csv('F:/docking_dataset/27w_docking_results/Average_Score/Average_Score.csv')

# 访问目标网页
# url = "https://zinc15.docking.org/substances/ZINC000034812154" # 替换为实际的 URL    

# 提取数据


    




# imformation.to_csv("Best_Score_info.csv")
# imformation.to_csv("Average_Score_info.csv")

# 输出结果
# print(compound_data)

# 关闭浏览器
# driver.quit()

















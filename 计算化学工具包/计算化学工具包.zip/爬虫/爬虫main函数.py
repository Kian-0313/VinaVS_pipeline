# -*- coding: utf-8 -*-
"""
Created on Wed Dec 11 10:28:39 2024

@author: yqz
"""
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from bs4 import BeautifulSoup
import time
import re
import pandas as pd
from 爬虫zinc分子特性封装 import get_compound_data

# 设置Chrome浏览器选项
options = webdriver.ChromeOptions()
options.add_argument('--headless')  # 可选，启动无头模式
options.add_argument(r"user-data-dir='F:/docking_dataset/'")
# 初始化ChromeDriver

# 使用 WebDriver Manager 自动安装并启动 ChromeDriver
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))



for i in range(12,15) :
    
    csv_path=f'F:/docking_dataset/27w_docking_results/300mol_every_batch/{i}/Best_Score.csv'
    df=pd.read_csv(csv_path)
    zinc_ids=df['ZINC_ID']
    
    
    # zinc_ids=zinc_ids[0:1]   #test command    
    
    imformation=get_compound_data(zinc_ids,driver,f'F:/docking_dataset/27w_docking_results/300mol_every_batch/{i}/Best_Score_info.csv')
    # print(zinc_id)
    # compound_data = get_compound_data(zinc_id)
    
    #转移至工具函数，一个循环保存一次
    # imformation.to_csv(f'F:/docking_dataset/27w_docking_results/每个日志中优秀的300个分子/{i}/Best_Score_info.csv')
      


'''测试单个zinc_id语句''' 
# zinc_ids=["ZINC000005084611"]
# imformation=get_compound_data(zinc_ids,driver) 
    
   
driver.quit()   
    
    
    
    
    
    
    
    
    
    
    
    
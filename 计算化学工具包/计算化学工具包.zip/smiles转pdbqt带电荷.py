from meeko import MoleculePreparation
from rdkit import Chem
from rdkit.Chem  import AllChem
import os
import shutil
import time
import sys
import pandas as pd

# dt=pd.read_csv("F:/docking_dataset/zinc/output_MW200-350/smi_MW200-350.csv")
# smiles=dt["smiles"]
# for i in range(len(smiles)):
#  compound = smiles[i]
# # 定义一个 SMILES 字符串
#  smiles_string = compound  
smiles_string="[NH3+][C@H]1CCC[C@H]1CCN1Cc2ccccc2F)C[C@@H]1C"
# 使用 RDKit 将 SMILES 转换为 RDKit 分子对象
mol = Chem.MolFromSmiles(smiles_string)
if mol is None:
    print("SMILES 解析失败，请检查输入是否正确。")
mol = Chem.AddHs(mol)  # 补充氢原子
AllChem.EmbedMolecule(mol)  # 为分子生成 3D 坐标
AllChem.UFFOptimizeMolecule(mol)  # 使用 UFF 力场优化分子几何
 
 
 
# 转换为 PDBQT 格式 
preparator = MoleculePreparation()
preparator.prepare(mol)  # 使用 RDKit 分子对象进行预处理
pdbqt_string = preparator.write_pdbqt_string()  # 生成 PDBQT 格式的字符串
print(pdbqt_string)
# # 打印或保存结果
# with open(f"F:/docking_dataset/zinc/output_MW200-350/output/{i}.pdbqt", "w") as f:
#    f.write(pdbqt_string)
# print("生成成功")














